import Carousel from '../components/Carousel/Carousel';
import { carouselData } from '../assets/data';

const Home = () => {
  return (
    <div className="home">
      <section className="hero-section">
        <Carousel slides={carouselData} />
      </section>
      <div className="content-section">
        <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-center mb-8">Welcome to Joe's Website</h1>
          <p className="text-xl text-center text-gray-300 mb-12">
            Explore our services and discover how we can bring your vision to life
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Innovation', desc: 'Pushing boundaries with cutting-edge solutions' },
              { title: 'Quality', desc: 'Delivering excellence in every project' },
              { title: 'Results', desc: 'Achieving measurable success for our clients' }
            ].map((item, index) => (
              <div key={index} className="bg-gray-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <h3 className="text-xl font-semibold mb-4">{item.title}</h3>
                <p className="text-gray-300">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;