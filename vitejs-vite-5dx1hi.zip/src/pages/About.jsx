const About = () => {
  return (
    <div className="page">
      <h1>About Us</h1>
      <p>We are a creative team passionate about delivering exceptional digital solutions.</p>
    </div>
  );
};

export default About;