const Projects = () => {
  return (
    <div className="page">
      <h1>Our Projects</h1>
      <p>Check out some of our recent work and achievements.</p>
    </div>
  );
};

export default Projects;