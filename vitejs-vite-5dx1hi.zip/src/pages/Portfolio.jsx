const Portfolio = () => {
  return (
    <div className="page">
      <h1>Portfolio</h1>
      <p>Browse through our collection of successful projects and case studies.</p>
    </div>
  );
};

export default Portfolio;