const app = () => {
  return (
    <div>
      <h1>Hii</h1>
    </div>
  );
};
export default app;
