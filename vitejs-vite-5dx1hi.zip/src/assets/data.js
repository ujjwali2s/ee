export const navLinks = [
  {
    id: 1,
    title: "About",
    path: "/about"
  },
  {
    id: 2,
    title: "Projects",
    path: "/projects"
  },
  {
    id: 3,
    title: "Portfolio",
    path: "/portfolio"
  },
  {
    id: 4,
    title: "Contact",
    path: "/contact"
  }
];

export const carouselData = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1707343843437-caacff5cfa74",
    alt: "Modern Architecture",
    title: "Innovative Design",
    description: "Creating spaces that inspire and transform"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1707345512638-997d31a10eaa",
    alt: "Digital Solutions",
    title: "Digital Excellence",
    description: "Pushing the boundaries of digital innovation"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1707327956851-30a531b70cda",
    alt: "Creative Work",
    title: "Creative Vision",
    description: "Bringing ideas to life with passion"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1707243510881-1c6c35fd6f8f",
    alt: "Technology",
    title: "Tech Forward",
    description: "Embracing future technologies"
  },
  {
    id: 5,
    url: "https://images.unsplash.com/photo-1707237159946-e3a2749c86bd",
    alt: "Collaboration",
    title: "Team Success",
    description: "Building success together"
  }
];