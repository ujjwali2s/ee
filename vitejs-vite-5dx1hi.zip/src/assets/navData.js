export const navLinks = [
  {
    id: 1,
    title: "About",
    path: "/about"
  },
  {
    id: 2,
    title: "Projects",
    path: "/projects"
  },
  {
    id: 3,
    title: "Portfolio",
    path: "/portfolio"
  },
  {
    id: 4,
    title: "Contact",
    path: "/contact"
  }
];